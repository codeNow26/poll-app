import { Component, input } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { SurveyCategory } from '../../types/survey-category.type';
import { SurveyForm } from '../../types/survey-form.types';

@Component({
  selector: 'app-survey-details',
  imports: [ReactiveFormsModule],
  templateUrl: './survey-details.html',
  styleUrl: './survey-details.scss',
})
export class SurveyDetails {
  form = input.required<SurveyForm>();
  maxTitleLength = input.required<number>();
  maxDescriptionLength = input.required<number>();
  minimumDate = input.required<string>();

  isCategoryDropdownOpen: boolean = false;

  categories: SurveyCategory[] = [
    'Health & Wellness',
    'Gaming & Entertainment',
    'Education & Learning',
    'Team Activities',
    'Lifestyle & Preferences',
    'Technology & Innovation',
  ];

  /**
   * Updates the selected category and closes the dropdown.
   * @param category - Category selected from the dropdown.
   */
  selectCategory(category: SurveyCategory): void {
    this.form().controls.surveyCategory.setValue(category);
    this.isCategoryDropdownOpen = false;
  }
}