import { Injectable } from '@angular/core';
import { SurveyDraft } from '../types/survey-form.types';

const SURVEY_DRAFT_KEY: string = 'poll-app-survey-draft';

@Injectable({
  providedIn: 'root',
})
export class SurveyDraftService {
  /**
   * Stores the draft, including incomplete form values.
   * @param draft - Current survey form values.
   */
  save(draft: SurveyDraft): void {
    try {
      localStorage.setItem(SURVEY_DRAFT_KEY, JSON.stringify(draft));
    } catch (error: unknown) {
      console.error('Survey draft could not be saved:', error);
    }
  }

  /**
   * Reads the stored draft without assuming its structure is valid.
   * @returns Parsed draft data, or null if unavailable.
   */
  load(): unknown {
    try {
      const storedDraft: string | null = localStorage.getItem(SURVEY_DRAFT_KEY);
      return storedDraft === null ? null : JSON.parse(storedDraft);
    } catch (error: unknown) {
      console.error('Survey draft could not be loaded:', error);
      return null;
    }
  }

  /** Removes the draft after a successful publication. */
  clear(): void {
    try {
      localStorage.removeItem(SURVEY_DRAFT_KEY);
    } catch (error: unknown) {
      console.error('Survey draft could not be removed:', error);
    }
  }
}